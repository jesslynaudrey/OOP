package com.example.unitalk;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import java.util.Scanner;
import java.io.*;
import java.sql.*;

public class CreateThread extends AppCompatActivity {
//    EditText myInput;
//    MyDBHandler DBHandler;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        EditText title = findViewById(R.id.title);
//        EditText content = findViewById(R.id.content);
//    }


    EditText editTitle, editContent;
    TextView result;
    ImageButton buttonPost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_thread);

        editTitle = (EditText) findViewById(R.id.title);
        editContent = (EditText) findViewById(R.id.content);
        result = (TextView) findViewById(R.id.result);
        buttonPost = (ImageButton) findViewById(R.id.post);
    /*
        Submit Button
    */
        buttonPost.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String strTitle = editTitle.getText().toString();
                String strContent = editContent.getText().toString();
                result.setText("Title:\t" + strTitle + "\nContent:\t" + strContent);
//                try {
//                    Thread.sleep(5000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
                openActivityView();
            }

        });

    /*
        Reset Button
    */
//        buttonReset.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                editName.setText("");
//                editPassword.setText("");
//                result.setText("");
//                editName.requestFocus();
//            }
//        });
    }

    public void openActivityView() {
        Intent intent = new Intent(this, ViewThreadActivity.class);
        startActivity(intent);
    }

    public String judulNow () {
        return editTitle.getText().toString();
    }

    public String kontenNow () {
        return editContent.getText().toString();
    }
}