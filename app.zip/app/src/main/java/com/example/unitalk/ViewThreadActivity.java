package com.example.unitalk;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class ViewThreadActivity extends AppCompatActivity {

    TextView strJudul, strKonten;
    ImageButton buttonComment;
    CreateThread t1 = new CreateThread();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_thread);

        strJudul = findViewById(R.id.judul);
        strKonten = findViewById(R.id.konten);
        buttonComment =  (ImageButton) findViewById(R.id.comment);

//        strJudul.setText(t1.judulNow());
//        strKonten.setText(t1.kontenNow());

        buttonComment.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openComment();

            }
        });
    }

    public void customClick(View view) {
        Toast.makeText(this, "like", Toast.LENGTH_SHORT).show();
    }

    public void openComment() {
        Intent intent = new Intent(this, Comment.class);
        startActivity(intent);
    }
}